window.onload = function() {

  function draw() {
    /* puteți folosi fontul digital-clock-font astfel:
       ctx.font = '75pt digital-clock-font'; */
   }
}
