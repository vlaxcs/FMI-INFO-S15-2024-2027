window.onload = function() {
   draw();
             
   function draw() {
       // desenăm ușa roșie
   }          
             
   function colorBlack() {
      // colorăm ușa în negru    
   }
}   
        
       
      
