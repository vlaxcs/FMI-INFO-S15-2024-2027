window.onload = function() {
  var starttime = Date.now();
           
  function draw() {
     let nowtime = Date.now();
     // folosiți diferența nowtime - starttime pentru animație 
  } 
}       
